﻿using UnityEngine;

namespace Code
{
    public class Base : MonoBehaviour
    {
        internal void OnCollisionEnter2D (Collision2D other) {
           
            
        }
    }
}