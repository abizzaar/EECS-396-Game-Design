﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Globals {

    public static PlayerManager pm;
    public static EnemyManager em;
    public static GridManager gm;

}
