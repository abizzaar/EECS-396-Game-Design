﻿using UnityEngine;

namespace Assets.Other_Code
{
    public class Platform : MonoBehaviour { }
}
